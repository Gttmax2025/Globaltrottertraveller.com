import { Phone, Mail, Globe, Clock, MessageCircle } from "lucide-react";
import EnquiryForm from "@/components/EnquiryForm";

const contactDetails = [
  {
    icon: Phone,
    title: "Call Us",
    value: "6297076072",
    href: "tel:6297076072",
    color: "text-green-600",
    bg: "bg-green-50",
  },
  {
    icon: Mail,
    title: "Email Us",
    value: "info@globaltrottertraveller.com",
    href: "mailto:info@globaltrottertraveller.com",
    color: "text-blue-600",
    bg: "bg-blue-50",
  },
  {
    icon: Globe,
    title: "Website",
    value: "Global Trotter Traveller",
    href: "#",
    color: "text-purple-600",
    bg: "bg-purple-50",
  },
  {
    icon: Clock,
    title: "Working Hours",
    value: "Mon–Sat, 9:00 AM – 7:00 PM",
    href: null,
    color: "text-amber-600",
    bg: "bg-amber-50",
  },
];

export default function Contact() {
  return (
    <div className="pt-20">
      {/* Hero */}
      <section className="relative py-32 bg-[hsl(220,40%,12%)] overflow-hidden">
        <div
          className="absolute inset-0 bg-cover bg-center opacity-20"
          style={{ backgroundImage: "url('https://images.unsplash.com/photo-1521295121783-8a321d551ad2?w=1600&h=600&fit=crop')" }}
        />
        <div className="absolute inset-0 bg-gradient-to-b from-[hsl(220,40%,8%)]/60 to-[hsl(220,40%,12%)]" />
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="inline-flex items-center gap-2 text-accent text-sm font-semibold tracking-widest uppercase mb-4">
            <MessageCircle className="h-4 w-4" /> We're Here to Help
          </div>
          <h1
            className="text-5xl sm:text-6xl font-bold text-white mb-4"
            style={{ fontFamily: "'Playfair Display', serif" }}
          >
            Contact Us
          </h1>
          <p className="text-white/70 text-xl max-w-2xl mx-auto">
            Have questions about a destination or need a custom package? Our travel experts are just a call or message away.
          </p>
        </div>
      </section>

      {/* Contact Cards */}
      <section className="py-16 bg-background">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {contactDetails.map((c) => (
              <div
                key={c.title}
                className="bg-white border border-border rounded-2xl p-6 text-center hover:shadow-md transition-all"
                data-testid={`card-contact-${c.title.toLowerCase().replace(/\s+/g, "-")}`}
              >
                <div className={`inline-flex items-center justify-center w-12 h-12 rounded-xl ${c.bg} mb-4 mx-auto`}>
                  <c.icon className={`h-6 w-6 ${c.color}`} />
                </div>
                <p className="text-xs text-muted-foreground font-semibold uppercase tracking-wider mb-1">{c.title}</p>
                {c.href ? (
                  <a
                    href={c.href}
                    className="font-semibold text-foreground hover:text-primary transition-colors text-sm break-all"
                    data-testid={`link-contact-${c.title.toLowerCase().replace(/\s+/g, "-")}`}
                  >
                    {c.value}
                  </a>
                ) : (
                  <p className="font-semibold text-foreground text-sm">{c.value}</p>
                )}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Enquiry Form + Info */}
      <section className="py-16 bg-muted/30">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-start">
            {/* Left: Info */}
            <div>
              <div className="mb-8">
                <img
                  src="/logo.png"
                  alt="Global Trotter Traveller"
                  className="h-20 w-auto object-contain mb-6"
                />
                <h2
                  className="text-3xl sm:text-4xl font-bold text-foreground mb-4"
                  style={{ fontFamily: "'Playfair Display', serif" }}
                >
                  Let's Plan Your Perfect Journey
                </h2>
                <p className="text-muted-foreground leading-relaxed mb-6">
                  Whether you're dreaming of a romantic getaway to Paris, a family adventure in Rajasthan, or need help with your visa application — we're here to make it happen seamlessly.
                </p>
              </div>

              <div className="space-y-4">
                <div className="flex items-center gap-4 p-4 bg-white rounded-xl border border-border">
                  <div className="w-10 h-10 flex items-center justify-center bg-green-50 rounded-xl flex-shrink-0">
                    <Phone className="h-5 w-5 text-green-600" />
                  </div>
                  <div>
                    <p className="text-xs text-muted-foreground font-medium uppercase tracking-wider">Phone</p>
                    <a href="tel:6297076072" className="font-bold text-foreground text-lg hover:text-primary transition-colors" data-testid="contact-phone">
                      6297076072
                    </a>
                  </div>
                </div>

                <div className="flex items-center gap-4 p-4 bg-white rounded-xl border border-border">
                  <div className="w-10 h-10 flex items-center justify-center bg-blue-50 rounded-xl flex-shrink-0">
                    <Mail className="h-5 w-5 text-blue-600" />
                  </div>
                  <div>
                    <p className="text-xs text-muted-foreground font-medium uppercase tracking-wider">Email</p>
                    <a href="mailto:info@globaltrottertraveller.com" className="font-bold text-foreground hover:text-primary transition-colors text-sm break-all" data-testid="contact-email">
                      info@globaltrottertraveller.com
                    </a>
                  </div>
                </div>

                <div className="flex items-center gap-4 p-4 bg-white rounded-xl border border-border">
                  <div className="w-10 h-10 flex items-center justify-center bg-amber-50 rounded-xl flex-shrink-0">
                    <Clock className="h-5 w-5 text-amber-600" />
                  </div>
                  <div>
                    <p className="text-xs text-muted-foreground font-medium uppercase tracking-wider">Office Hours</p>
                    <p className="font-semibold text-foreground">Mon–Sat: 9:00 AM – 7:00 PM</p>
                  </div>
                </div>
              </div>

              <div className="mt-8 bg-primary/5 border border-primary/20 rounded-2xl p-6">
                <h3 className="font-bold text-foreground mb-2" style={{ fontFamily: "'Playfair Display', serif" }}>About Global Trotter Traveller</h3>
                <p className="text-muted-foreground text-sm leading-relaxed">
                  We are a dedicated travel agency committed to providing exceptional travel experiences. From domestic getaways to international adventures, hotel bookings, flight reservations, and visa services — we handle everything so you can focus on creating memories.
                </p>
              </div>
            </div>

            {/* Right: Form */}
            <div>
              <div className="bg-white rounded-3xl shadow-xl border border-border p-8">
                <h3
                  className="text-2xl font-bold text-foreground mb-2"
                  style={{ fontFamily: "'Playfair Display', serif" }}
                >
                  Send an Enquiry
                </h3>
                <p className="text-muted-foreground text-sm mb-6">
                  Fill in your details and we'll get back to you within 24 hours.
                </p>
                <EnquiryForm />
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
