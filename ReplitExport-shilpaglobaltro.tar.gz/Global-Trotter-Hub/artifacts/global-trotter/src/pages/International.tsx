import { useState } from "react";
import { Globe, ArrowRight, X, Phone } from "lucide-react";
import EnquiryForm from "@/components/EnquiryForm";

const internationalPackages = [
  {
    id: "dubai",
    name: "Dubai",
    country: "United Arab Emirates",
    tagline: "City of Gold & Wonder",
    duration: "4N / 5D",
    img: "https://images.unsplash.com/photo-1512453979798-5ea266f8880c?w=600&h=400&fit=crop",
    highlights: ["Burj Khalifa", "Dubai Mall", "Desert Safari", "Dubai Creek", "Palm Jumeirah"],
    description: "Experience the ultimate blend of ultra-modern luxury and ancient Arabian culture in the world's most glamorous city.",
  },
  {
    id: "paris",
    name: "Paris",
    country: "France",
    tagline: "City of Light & Love",
    duration: "5N / 6D",
    img: "https://images.unsplash.com/photo-1502602898657-3e91760cbb34?w=600&h=400&fit=crop",
    highlights: ["Eiffel Tower", "Louvre Museum", "Seine River Cruise", "Versailles Palace", "Montmartre"],
    description: "Fall in love with the timeless elegance of Paris — its world-class art, haute cuisine, romantic boulevards, and iconic landmarks.",
  },
  {
    id: "singapore",
    name: "Singapore",
    country: "Singapore",
    tagline: "The Lion City",
    duration: "4N / 5D",
    img: "https://images.unsplash.com/photo-1525625293386-3f8f99389edd?w=600&h=400&fit=crop",
    highlights: ["Marina Bay Sands", "Gardens by the Bay", "Sentosa Island", "Universal Studios", "Clarke Quay"],
    description: "A futuristic city-state where gleaming skyscrapers meet lush greenery, where Asian cultures blend harmoniously, and every meal is an adventure.",
  },
  {
    id: "maldives",
    name: "Maldives",
    country: "Republic of Maldives",
    tagline: "Paradise on Earth",
    duration: "4N / 5D",
    img: "https://images.unsplash.com/photo-1573843981267-be1999ff37cd?w=600&h=400&fit=crop",
    highlights: ["Overwater Bungalow", "Snorkeling & Diving", "Dolphin Watching", "Sunset Cruises", "Private Beach"],
    description: "Lose yourself in the most stunning island paradise — crystal lagoons, endless blue skies, and overwater villas that redefine luxury.",
  },
  {
    id: "phuket-krabi",
    name: "Phuket & Krabi",
    country: "Kingdom of Thailand",
    tagline: "Islands, Cliffs & Crystal Seas",
    duration: "5N / 6D",
    img: "https://images.unsplash.com/photo-1552465011-b4e21bf6e79a?w=600&h=400&fit=crop",
    highlights: ["Phi Phi Islands", "Maya Bay", "Krabi Rock Climbing", "Tiger Cave Temple", "James Bond Island", "Patong Beach"],
    description: "Two of Thailand's most iconic island destinations in one — Phuket's lively beaches and nightlife paired with Krabi's dramatic limestone karsts and emerald lagoons.",
  },
  {
    id: "bangkok-pattaya",
    name: "Bangkok & Pattaya",
    country: "Kingdom of Thailand",
    tagline: "City Thrills & Beach Vibes",
    duration: "4N / 5D",
    img: "https://images.unsplash.com/photo-1508009603885-50cf7c579365?w=600&h=400&fit=crop",
    highlights: ["Grand Palace & Wat Pho", "Pattaya Coral Island", "Walking Street", "Alcazar Cabaret Show", "Chatuchak Weekend Market", "Floating Markets"],
    description: "Bangkok's dazzling temples and street food scene followed by Pattaya's beach resorts and electric nightlife — the perfect Thai combo for every kind of traveller.",
  },
  {
    id: "bali",
    name: "Bali",
    country: "Republic of Indonesia",
    tagline: "Island of Gods",
    duration: "5N / 6D",
    img: "https://images.unsplash.com/photo-1537996194471-e657df975ab4?w=600&h=400&fit=crop",
    highlights: ["Ubud Rice Terraces", "Tanah Lot Temple", "Kuta Beach", "Mount Batur Sunrise Trek", "Uluwatu Cliff Temple", "Seminyak Sunset"],
    description: "Bali casts a spell like no other — rice terraces, volcanic peaks, sacred temples, world-class surf, lush rice paddies and a spiritual atmosphere that stays with you long after you leave.",
  },
  {
    id: "malaysia",
    name: "Malaysia",
    country: "Malaysia",
    tagline: "Truly Asia",
    duration: "5N / 6D",
    img: "https://images.unsplash.com/photo-1529074963764-98f45c47344b?w=600&h=400&fit=crop",
    highlights: ["Petronas Twin Towers", "Langkawi Island", "Batu Caves", "Genting Highlands", "Penang Heritage Town", "Kuala Lumpur City Tour"],
    description: "Malaysia dazzles with iconic twin towers, pristine tropical islands, heritage streets, lush rainforests, and a melting pot of Malay, Chinese, and Indian cultures all in one remarkable destination.",
  },
  {
    id: "switzerland",
    name: "Switzerland",
    country: "Swiss Confederation",
    tagline: "Alps, Lakes & Luxury",
    duration: "6N / 7D",
    img: "https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=600&h=400&fit=crop",
    highlights: ["Interlaken", "Jungfraujoch", "Lucerne Old Town", "Lake Geneva", "Zurich City"],
    description: "Breathe in the crisp mountain air, cruise past mirror-like lakes, and experience the pinnacle of European beauty and precision.",
  },
  {
    id: "vietnam",
    name: "Vietnam",
    country: "Socialist Republic of Vietnam",
    tagline: "Ancient Beauty & Hidden Wonders",
    duration: "6N / 7D",
    img: "https://images.unsplash.com/photo-1559592413-7cec4d0cae2b?w=600&h=400&fit=crop",
    highlights: ["Ha Long Bay Cruise", "Hoi An Ancient Town", "Ho Chi Minh City", "Sapa Rice Terraces", "Hue Imperial City", "Vietnamese Street Food"],
    description: "Journey through a land of breathtaking natural beauty — emerald bays, golden lantern towns, misty mountain valleys, and a cuisine that captivates every palate.",
  },
  {
    id: "uk-scotland",
    name: "UK & Scotland",
    country: "United Kingdom",
    tagline: "Castles, Highlands & History",
    duration: "8N / 9D",
    img: "https://images.unsplash.com/photo-1508193638397-1c4234db14d8?w=600&h=400&fit=crop",
    highlights: ["Edinburgh Castle", "Scottish Highlands", "Loch Ness", "London Landmarks", "Isle of Skye", "Glencoe Valley", "Royal Mile", "Stonehenge"],
    description: "From London's royal grandeur to the dramatic mist-shrouded Highlands — explore ancient castles, legendary lochs, wild mountain glens, and a culture steeped in centuries of fascinating history.",
  },
  {
    id: "eastern-europe",
    name: "Eastern Europe",
    country: "Multi-Country — Europe",
    tagline: "Prague, Budapest & Vienna",
    duration: "8N / 9D",
    img: "https://images.unsplash.com/photo-1541849546-216549ae216d?w=600&h=400&fit=crop",
    highlights: ["Prague Old Town Square", "Charles Bridge", "Budapest Parliament", "Thermal Baths", "Vienna Opera House", "Schönbrunn Palace", "Bratislava Castle", "Danube River Cruise"],
    description: "Three of Europe's most breathtaking capitals in one unforgettable journey — Prague's Gothic spires, Budapest's grand boulevards and thermal baths, and Vienna's imperial palaces and classical music heritage.",
  },
];

export default function International() {
  const [selectedDest, setSelectedDest] = useState<string | null>(null);
  const selected = internationalPackages.find((p) => p.id === selectedDest);

  return (
    <div className="pt-20">
      {/* Hero */}
      <section className="relative py-32 bg-[hsl(220,40%,12%)] overflow-hidden">
        <div
          className="absolute inset-0 bg-cover bg-center opacity-25"
          style={{ backgroundImage: "url('https://images.unsplash.com/photo-1476514525535-07fb3b4ae5f1?w=1600&h=600&fit=crop')" }}
        />
        <div className="absolute inset-0 bg-gradient-to-b from-[hsl(220,40%,8%)]/60 to-[hsl(220,40%,12%)]" />
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="inline-flex items-center gap-2 text-accent text-sm font-semibold tracking-widest uppercase mb-4">
            <Globe className="h-4 w-4" /> Explore the World
          </div>
          <h1
            className="text-5xl sm:text-6xl font-bold text-white mb-4"
            style={{ fontFamily: "'Playfair Display', serif" }}
          >
            International Packages
          </h1>
          <p className="text-white/70 text-xl max-w-2xl mx-auto">
            From the deserts of Dubai to the Alps of Switzerland — we take you there in style and comfort.
          </p>
        </div>
      </section>

      {/* Packages Grid */}
      <section className="py-20 bg-background">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {internationalPackages.map((pkg) => (
              <div
                key={pkg.id}
                className="group bg-white border border-border rounded-2xl overflow-hidden hover:shadow-xl transition-all duration-300 hover:-translate-y-1"
                data-testid={`card-package-${pkg.id}`}
              >
                <div className="relative overflow-hidden aspect-[4/3]">
                  <img
                    src={pkg.img}
                    alt={pkg.name}
                    className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                  />
                  <div className="absolute top-4 left-4 bg-white/90 backdrop-blur-sm text-foreground text-xs font-semibold px-3 py-1.5 rounded-full">
                    {pkg.country}
                  </div>
                  <div className="absolute top-4 right-4 bg-accent text-white text-xs font-bold px-3 py-1.5 rounded-full">
                    {pkg.duration}
                  </div>
                </div>
                <div className="p-6">
                  <p className="text-accent text-xs font-semibold tracking-widest uppercase mb-1">{pkg.tagline}</p>
                  <h3
                    className="text-2xl font-bold text-foreground mb-3"
                    style={{ fontFamily: "'Playfair Display', serif" }}
                  >
                    {pkg.name}
                  </h3>
                  <p className="text-muted-foreground text-sm mb-4 leading-relaxed">{pkg.description}</p>
                  <div className="space-y-1.5 mb-6">
                    {pkg.highlights.slice(0, 3).map((h) => (
                      <div key={h} className="flex items-center gap-2 text-sm text-foreground/80">
                        <div className="w-1.5 h-1.5 rounded-full bg-accent flex-shrink-0" />
                        {h}
                      </div>
                    ))}
                    {pkg.highlights.length > 3 && (
                      <div className="text-xs text-muted-foreground">+{pkg.highlights.length - 3} more highlights</div>
                    )}
                  </div>
                  <button
                    onClick={() => setSelectedDest(pkg.id)}
                    className="w-full flex items-center justify-center gap-2 bg-primary hover:bg-primary/90 text-white font-semibold py-3 px-6 rounded-xl transition-all duration-200 hover:shadow-md"
                    data-testid={`button-enquire-${pkg.id}`}
                  >
                    Enquire Now <ArrowRight className="h-4 w-4" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-16 bg-accent">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2
            className="text-3xl sm:text-4xl font-bold text-white mb-4"
            style={{ fontFamily: "'Playfair Display', serif" }}
          >
            Need a Custom International Tour?
          </h2>
          <p className="text-white/80 text-lg mb-8">
            Tell us your dream destination and we'll craft the perfect itinerary for you.
          </p>
          <a
            href="tel:6297076072"
            className="inline-flex items-center gap-2 bg-white text-accent hover:bg-white/90 font-semibold px-8 py-4 rounded-xl transition-all shadow-lg hover:shadow-xl"
            data-testid="cta-call"
          >
            <Phone className="h-5 w-5" />
            Call Us: 6297076072
          </a>
        </div>
      </section>

      {/* Enquiry Modal */}
      {selected && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm"
          onClick={(e) => { if (e.target === e.currentTarget) setSelectedDest(null); }}
        >
          <div className="bg-white rounded-3xl shadow-2xl max-w-lg w-full max-h-[90vh] overflow-y-auto">
            <div className="p-6 border-b border-border flex items-center justify-between">
              <div>
                <h3 className="text-xl font-bold text-foreground" style={{ fontFamily: "'Playfair Display', serif" }}>
                  Enquire — {selected.name}
                </h3>
                <p className="text-muted-foreground text-sm">{selected.country}</p>
              </div>
              <button
                onClick={() => setSelectedDest(null)}
                className="p-2 rounded-lg hover:bg-muted transition-colors"
                data-testid="button-close-modal"
              >
                <X className="h-5 w-5" />
              </button>
            </div>
            <div className="p-6">
              <EnquiryForm defaultDestination={selected.name} compact />
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
