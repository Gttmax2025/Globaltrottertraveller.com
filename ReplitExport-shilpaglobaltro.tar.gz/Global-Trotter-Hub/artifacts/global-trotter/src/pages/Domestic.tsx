import { useState } from "react";
import { MapPin, ArrowRight, X, Phone } from "lucide-react";
import EnquiryForm from "@/components/EnquiryForm";

const domesticPackages = [
  {
    id: "goa",
    name: "Goa",
    tagline: "Sun, Sand & Serenity",
    duration: "3N / 4D",
    img: "https://images.unsplash.com/photo-1512343879784-a960bf40e7f2?w=600&h=400&fit=crop",
    highlights: ["North & South Goa Beaches", "Old Goa Churches", "Dudhsagar Falls", "Spice Plantation Tour", "Water Sports"],
    description: "Experience the perfect blend of Portuguese heritage, golden beaches, vibrant nightlife, and mouthwatering seafood in India's beach capital.",
  },
  {
    id: "kerala",
    name: "Kerala Backwaters",
    tagline: "God's Own Country",
    duration: "4N / 5D",
    img: "https://images.unsplash.com/photo-1593693397690-362cb9666fc2?w=600&h=400&fit=crop",
    highlights: ["Alleppey Houseboat Stay", "Munnar Tea Gardens", "Thekkady Wildlife", "Kovalam Beach", "Kathakali Dance Show"],
    description: "Glide through tranquil backwaters on a houseboat, explore misty tea plantations, and discover the magic of India's tropical paradise.",
  },
  {
    id: "rajasthan",
    name: "Rajasthan",
    tagline: "Land of Maharajas",
    duration: "6N / 7D",
    img: "https://images.unsplash.com/photo-1599661046827-dacff0c0f09a?w=600&h=400&fit=crop",
    highlights: ["Jaipur Pink City", "Udaipur Lake Palace", "Jodhpur Blue City", "Jaisalmer Desert Safari", "Amber Fort"],
    description: "Step into a royal world of magnificent forts, colorful bazaars, golden desert dunes, and warm Rajasthani hospitality.",
  },
  {
    id: "himachal",
    name: "Himachal Pradesh",
    tagline: "Heaven on Earth",
    duration: "5N / 6D",
    img: "https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=600&h=400&fit=crop",
    highlights: ["Shimla Heritage", "Manali Snow Points", "Rohtang Pass", "Kullu River Rafting", "Dalhousie Colonial Charm"],
    description: "Escape to snow-capped peaks, lush valleys, ancient temples, and charming hill stations in the jewel of the Himalayas.",
  },
  {
    id: "ladakh",
    name: "Leh Ladakh",
    tagline: "Land of High Passes",
    duration: "6N / 7D",
    img: "https://images.unsplash.com/photo-1626621341517-bbf3d9990a23?w=600&h=400&fit=crop",
    highlights: ["Pangong Lake", "Nubra Valley", "Khardung La Pass", "Thiksey Monastery", "Magnetic Hill"],
    description: "Journey to the roof of the world — where turquoise lakes, ancient monasteries, and dramatic landscapes take your breath away.",
  },
  {
    id: "andaman",
    name: "Andaman & Nicobar",
    tagline: "Emerald Islands",
    duration: "4N / 5D",
    img: "https://images.unsplash.com/photo-1559628376-f3fe5f782a2e?w=600&h=400&fit=crop",
    highlights: ["Radhanagar Beach", "Havelock Island", "Scuba Diving", "Cellular Jail", "Neil Island"],
    description: "Discover pristine white-sand beaches, crystal-clear turquoise waters, and vibrant coral reefs in India's tropical island paradise.",
  },
  {
    id: "arunachal",
    name: "Arunachal with Tawang",
    tagline: "Land of the Rising Sun",
    duration: "7N / 8D",
    img: "https://images.unsplash.com/photo-1626621341517-bbf3d9990a23?w=600&h=400&fit=crop",
    highlights: ["Tawang Monastery", "Sela Pass", "Bum La Pass", "Madhuri Lake", "Nuranang Waterfall", "Bomdila Town"],
    description: "Explore the mystical land of monasteries and mountain passes — Tawang's ancient Gelugpa monastery, high-altitude Sela Pass at 13,700 ft, and pristine Himalayan valleys untouched by time.",
  },
  {
    id: "anini",
    name: "Anini Mechuka Route",
    tagline: "India's Hidden Frontier",
    duration: "7N / 8D",
    img: "https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=600&h=400&fit=crop",
    highlights: ["Mechuka Valley", "Anini — India's Remotest Town", "Tsangpo River", "Tribal Culture", "Dibang Valley", "Ita Fort Itanagar"],
    description: "Venture into one of India's last great frontiers — the remote Dibang and Mechuka valleys of Lower Dibang District, where pristine nature, Adi tribal heritage, and untouched river gorges await.",
  },
  {
    id: "kashmir",
    name: "Kashmir",
    tagline: "Paradise on Earth",
    duration: "5N / 6D",
    img: "https://images.unsplash.com/photo-1605649487212-47bdab064df7?w=600&h=400&fit=crop",
    highlights: ["Dal Lake Shikara Ride", "Gulmarg Gondola", "Pahalgam Valley", "Mughal Gardens", "Sonmarg Glacier", "Houseboat Stay"],
    description: "Float on the mirror-still Dal Lake, ride the world's highest gondola in Gulmarg, and wander through flower-carpeted meadows in the valley that Mughal emperors called heaven on earth.",
  },
  {
    id: "assam-meghalaya",
    name: "Assam & Meghalaya",
    tagline: "Abode of Clouds & Wild Jungles",
    duration: "6N / 7D",
    img: "https://images.unsplash.com/photo-1593693397690-362cb9666fc2?w=600&h=400&fit=crop",
    highlights: ["Kaziranga National Park", "Living Root Bridges — Cherrapunji", "Dawki River", "Shillong Peak", "Mawlynnong — Asia's Cleanest Village", "Umiah Lake"],
    description: "From the one-horned rhinos of Kaziranga to the living root bridges of Meghalaya's wettest hills — this journey takes you through northeast India's most breathtaking natural wonders.",
  },
  {
    id: "dalhousie-dharamshala",
    name: "Dalhousie & Dharamshala",
    tagline: "Colonial Charm & Tibetan Soul",
    duration: "5N / 6D",
    img: "https://images.unsplash.com/photo-1587474260584-136574528ed5?w=600&h=400&fit=crop",
    highlights: ["Dalhousie Mall Road", "Khajjiar — Mini Switzerland", "McLeod Ganj", "Dharamshala Cricket Stadium", "Triund Trek", "Tibetan Monastery"],
    description: "Wander through the colonial streets of Dalhousie, visit the enchanting Khajjiar meadows, and discover the vibrant Tibetan culture of McLeod Ganj — home of the Dalai Lama.",
  },
  {
    id: "spiti-valley",
    name: "Spiti Valley",
    tagline: "Land of Lamas & Lunar Landscapes",
    duration: "7N / 8D",
    img: "https://images.unsplash.com/photo-1626621341517-bbf3d9990a23?w=600&h=400&fit=crop",
    highlights: ["Key Monastery", "Kaza Town", "Chandratal Lake", "Kunzum Pass", "Pin Valley National Park", "Kibber Village", "Dhankar Monastery"],
    description: "A raw, high-altitude cold desert in the heart of the Himalayas — stark lunar landscapes, ancient Buddhist monasteries perched on cliffsides, and a journey that tests your spirit at every turn.",
  },
];

export default function Domestic() {
  const [selectedDest, setSelectedDest] = useState<string | null>(null);
  const selected = domesticPackages.find((p) => p.id === selectedDest);

  return (
    <div className="pt-20">
      {/* Hero */}
      <section className="relative py-32 bg-[hsl(220,40%,12%)] overflow-hidden">
        <div
          className="absolute inset-0 bg-cover bg-center opacity-25"
          style={{ backgroundImage: "url('https://images.unsplash.com/photo-1524492412937-b28074a5d7da?w=1600&h=600&fit=crop')" }}
        />
        <div className="absolute inset-0 bg-gradient-to-b from-[hsl(220,40%,8%)]/60 to-[hsl(220,40%,12%)]" />
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="inline-flex items-center gap-2 text-accent text-sm font-semibold tracking-widest uppercase mb-4">
            <MapPin className="h-4 w-4" /> Explore India
          </div>
          <h1
            className="text-5xl sm:text-6xl font-bold text-white mb-4"
            style={{ fontFamily: "'Playfair Display', serif" }}
          >
            Domestic Packages
          </h1>
          <p className="text-white/70 text-xl max-w-2xl mx-auto">
            Discover the incredible diversity of India — from the beaches of Goa to the peaks of Ladakh.
          </p>
        </div>
      </section>

      {/* Packages Grid */}
      <section className="py-20 bg-background">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {domesticPackages.map((pkg) => (
              <div
                key={pkg.id}
                className="group bg-white border border-border rounded-2xl overflow-hidden hover:shadow-xl transition-all duration-300 hover:-translate-y-1"
                data-testid={`card-package-${pkg.id}`}
              >
                <div className="relative overflow-hidden aspect-[4/3]">
                  <img
                    src={pkg.img}
                    alt={pkg.name}
                    className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                  />
                  <div className="absolute top-4 right-4 bg-accent text-white text-xs font-bold px-3 py-1.5 rounded-full">
                    {pkg.duration}
                  </div>
                </div>
                <div className="p-6">
                  <p className="text-accent text-xs font-semibold tracking-widest uppercase mb-1">{pkg.tagline}</p>
                  <h3
                    className="text-2xl font-bold text-foreground mb-3"
                    style={{ fontFamily: "'Playfair Display', serif" }}
                  >
                    {pkg.name}
                  </h3>
                  <p className="text-muted-foreground text-sm mb-4 leading-relaxed">{pkg.description}</p>
                  <div className="space-y-1.5 mb-6">
                    {pkg.highlights.slice(0, 3).map((h) => (
                      <div key={h} className="flex items-center gap-2 text-sm text-foreground/80">
                        <div className="w-1.5 h-1.5 rounded-full bg-accent flex-shrink-0" />
                        {h}
                      </div>
                    ))}
                    {pkg.highlights.length > 3 && (
                      <div className="text-xs text-muted-foreground">+{pkg.highlights.length - 3} more highlights</div>
                    )}
                  </div>
                  <button
                    onClick={() => setSelectedDest(pkg.id)}
                    className="w-full flex items-center justify-center gap-2 bg-primary hover:bg-primary/90 text-white font-semibold py-3 px-6 rounded-xl transition-all duration-200 hover:shadow-md"
                    data-testid={`button-enquire-${pkg.id}`}
                  >
                    Enquire Now <ArrowRight className="h-4 w-4" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-16 bg-primary">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2
            className="text-3xl sm:text-4xl font-bold text-white mb-4"
            style={{ fontFamily: "'Playfair Display', serif" }}
          >
            Can't Find Your Dream Destination?
          </h2>
          <p className="text-white/80 text-lg mb-8">
            We create custom itineraries tailored to your preferences, budget, and travel dates.
          </p>
          <a
            href="tel:6297076072"
            className="inline-flex items-center gap-2 bg-accent hover:bg-accent/90 text-white font-semibold px-8 py-4 rounded-xl transition-all shadow-lg hover:shadow-xl"
            data-testid="cta-call"
          >
            <Phone className="h-5 w-5" />
            Call Us: 6297076072
          </a>
        </div>
      </section>

      {/* Enquiry Modal */}
      {selected && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm"
          onClick={(e) => { if (e.target === e.currentTarget) setSelectedDest(null); }}
        >
          <div className="bg-white rounded-3xl shadow-2xl max-w-lg w-full max-h-[90vh] overflow-y-auto">
            <div className="p-6 border-b border-border flex items-center justify-between">
              <div>
                <h3 className="text-xl font-bold text-foreground" style={{ fontFamily: "'Playfair Display', serif" }}>
                  Enquire — {selected.name}
                </h3>
                <p className="text-muted-foreground text-sm">{selected.tagline}</p>
              </div>
              <button
                onClick={() => setSelectedDest(null)}
                className="p-2 rounded-lg hover:bg-muted transition-colors"
                data-testid="button-close-modal"
              >
                <X className="h-5 w-5" />
              </button>
            </div>
            <div className="p-6">
              <EnquiryForm defaultDestination={selected.name} compact />
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
