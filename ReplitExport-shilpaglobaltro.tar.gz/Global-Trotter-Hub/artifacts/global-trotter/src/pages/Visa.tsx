import { useState } from "react";
import { FileText, ChevronDown, ChevronUp, Phone, Mail, CheckCircle2 } from "lucide-react";
import EnquiryForm from "@/components/EnquiryForm";

const visaServices = [
  {
    id: "schengen",
    country: "Schengen / Europe Visa",
    flag: "EU",
    processingTime: "15-20 Working Days",
    validFor: "Multiple Entry, 90 Days",
    checklist: [
      "Valid Passport (minimum 6 months validity with 2 blank pages)",
      "Recent passport-size photographs (white background, 35x45mm)",
      "Schengen Visa Application Form (signed)",
      "Travel Insurance (minimum EUR 30,000 coverage)",
      "Confirmed flight tickets (round trip)",
      "Hotel / accommodation booking confirmation",
      "Bank statement (last 3-6 months with sufficient balance)",
      "Income Tax Returns (last 2-3 years)",
      "Salary slips / proof of employment (last 3 months)",
      "Leave approval letter from employer",
      "No Objection Certificate (NOC) from employer",
      "Cover letter explaining purpose of visit",
      "Proof of residence (electricity/water bill)",
      "Invitation letter (if visiting friends/family)",
    ],
  },
  {
    id: "usa",
    country: "USA Visa (B1/B2 Tourist)",
    flag: "US",
    processingTime: "Varies (Interview Required)",
    validFor: "Up to 10 Years",
    checklist: [
      "Valid Passport (minimum 6 months beyond intended stay)",
      "DS-160 Online Application Form (completed and signed)",
      "Recent passport photograph (51x51mm, white background)",
      "Visa fee payment receipt (MRV Fee)",
      "Interview appointment letter",
      "Bank statements (last 6 months)",
      "Income Tax Returns (ITR) last 3 years",
      "Proof of employment / business ownership",
      "Property and asset documents",
      "Travel history documents (previous visas, if any)",
      "Hotel and itinerary details",
      "No Objection Certificate from employer",
      "Family ties in India (marriage certificate, children's birth certificates)",
    ],
  },
  {
    id: "uk",
    country: "UK Visitor Visa",
    flag: "GB",
    processingTime: "15 Working Days",
    validFor: "Up to 6 Months",
    checklist: [
      "Valid Passport (at least 6 months validity)",
      "Online Visa Application Form (completed)",
      "Recent passport-size photographs (UK specifications)",
      "Biometrics enrollment appointment",
      "Bank statements (last 6 months, minimum GBP 1000-2000)",
      "Employment letter and last 3 months salary slips",
      "Income Tax Returns (last 2-3 years)",
      "Property documents and assets",
      "Travel itinerary with hotel bookings",
      "Flight tickets (round trip)",
      "Proof of ties to home country",
      "Travel history (previous visas, if any)",
      "Marriage certificate (if applying jointly)",
    ],
  },
  {
    id: "dubai",
    country: "Dubai / UAE Tourist Visa",
    flag: "AE",
    processingTime: "3-5 Working Days",
    validFor: "30 or 60 Days",
    checklist: [
      "Valid Passport (minimum 6 months validity)",
      "Recent passport-size photograph (white background)",
      "Completed visa application form",
      "Bank statement (last 3 months with minimum balance)",
      "Confirmed return flight tickets",
      "Hotel booking confirmation",
      "Travel insurance",
      "For salaried: Salary slip, employment letter, NOC",
      "For self-employed: Business registration, bank statements",
      "Previous UAE visa copy (if any)",
    ],
  },
  {
    id: "singapore",
    country: "Singapore Tourist Visa",
    flag: "SG",
    processingTime: "5-7 Working Days",
    validFor: "30 Days (Single Entry)",
    checklist: [
      "Valid Passport (minimum 6 months validity with blank pages)",
      "Completed visa application form (V39A)",
      "Recent passport-size photograph (35x45mm)",
      "Bank statement (last 3-6 months)",
      "Income Tax Returns (latest)",
      "Employment proof (letter from employer, salary slips)",
      "Leave approval letter",
      "Confirmed flight tickets",
      "Hotel booking confirmation",
      "Cover letter stating purpose of visit",
      "Yellow fever vaccination certificate (if applicable)",
    ],
  },
  {
    id: "thailand",
    country: "Thailand Visa / Visa on Arrival",
    flag: "TH",
    processingTime: "On Arrival (30 Days Free for Indians)",
    validFor: "30 Days",
    checklist: [
      "Valid Passport (minimum 6 months validity, 2 blank pages)",
      "Recent passport-size photograph (white background)",
      "Proof of sufficient funds (THB 10,000 per person)",
      "Onward/return flight tickets",
      "Hotel booking confirmation",
      "Travel insurance (recommended)",
      "Filled arrival card (provided on flight)",
      "Yellow fever certificate (if arriving from endemic country)",
      "Note: For Visa on Arrival, fill the form at the airport counter",
    ],
  },
];

export default function Visa() {
  const [openId, setOpenId] = useState<string | null>("schengen");

  const toggleSection = (id: string) => {
    setOpenId(openId === id ? null : id);
  };

  return (
    <div className="pt-20">
      {/* Hero */}
      <section className="relative py-32 bg-[hsl(220,40%,12%)] overflow-hidden">
        <div
          className="absolute inset-0 bg-cover bg-center opacity-20"
          style={{ backgroundImage: "url('https://images.unsplash.com/photo-1569949380651-747098f02e55?w=1600&h=600&fit=crop')" }}
        />
        <div className="absolute inset-0 bg-gradient-to-b from-[hsl(220,40%,8%)]/60 to-[hsl(220,40%,12%)]" />
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="inline-flex items-center gap-2 text-accent text-sm font-semibold tracking-widest uppercase mb-4">
            <FileText className="h-4 w-4" /> Documentation Made Easy
          </div>
          <h1
            className="text-5xl sm:text-6xl font-bold text-white mb-4"
            style={{ fontFamily: "'Playfair Display', serif" }}
          >
            Visa Services
          </h1>
          <p className="text-white/70 text-xl max-w-2xl mx-auto">
            Expert visa assistance with complete document checklists. We guide you through every step of the process.
          </p>
        </div>
      </section>

      {/* Intro */}
      <section className="py-16 bg-background">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2
            className="text-3xl font-bold text-foreground mb-4"
            style={{ fontFamily: "'Playfair Display', serif" }}
          >
            Visa Assistance & Document Checklists
          </h2>
          <p className="text-muted-foreground text-lg leading-relaxed">
            Getting a visa doesn't have to be stressful. Our experienced team handles your visa application from start to finish. Use the checklists below to prepare your documents, then contact us to begin the process.
          </p>
        </div>
      </section>

      {/* Checklists Accordion */}
      <section className="pb-20 bg-background">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="space-y-4">
            {visaServices.map((visa) => (
              <div
                key={visa.id}
                className="border border-border rounded-2xl overflow-hidden bg-white shadow-sm hover:shadow-md transition-shadow"
                data-testid={`accordion-visa-${visa.id}`}
              >
                <button
                  className="w-full flex items-center justify-between px-6 py-5 text-left hover:bg-muted/30 transition-colors"
                  onClick={() => toggleSection(visa.id)}
                  data-testid={`button-accordion-${visa.id}`}
                >
                  <div className="flex items-center gap-4">
                    <div className="flex items-center justify-center w-10 h-10 bg-primary/10 rounded-xl text-primary font-bold text-sm">
                      {visa.flag}
                    </div>
                    <div>
                      <h3
                        className="text-lg font-bold text-foreground"
                        style={{ fontFamily: "'Playfair Display', serif" }}
                      >
                        {visa.country}
                      </h3>
                      <div className="flex items-center gap-4 mt-0.5">
                        <span className="text-xs text-muted-foreground">Processing: {visa.processingTime}</span>
                        <span className="text-xs text-accent font-medium">{visa.validFor}</span>
                      </div>
                    </div>
                  </div>
                  {openId === visa.id ? (
                    <ChevronUp className="h-5 w-5 text-primary flex-shrink-0" />
                  ) : (
                    <ChevronDown className="h-5 w-5 text-muted-foreground flex-shrink-0" />
                  )}
                </button>

                {openId === visa.id && (
                  <div className="px-6 pb-6 border-t border-border">
                    <p className="text-sm font-semibold text-primary mt-4 mb-3 uppercase tracking-wider">
                      Required Documents Checklist
                    </p>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                      {visa.checklist.map((item, idx) => (
                        <div key={idx} className="flex items-start gap-3 bg-muted/30 rounded-xl p-3">
                          <CheckCircle2 className="h-4 w-4 text-green-500 flex-shrink-0 mt-0.5" />
                          <span className="text-sm text-foreground/80 leading-snug">{item}</span>
                        </div>
                      ))}
                    </div>
                    <div className="mt-6 p-4 bg-accent/10 border border-accent/20 rounded-xl">
                      <p className="text-sm text-foreground/70">
                        <span className="font-semibold text-accent">Note:</span> Requirements may vary based on your travel history, purpose of visit, and nationality. Contact our visa experts for personalized guidance.
                      </p>
                    </div>
                    <button
                      onClick={() => {
                        const el = document.getElementById("visa-enquiry");
                        el?.scrollIntoView({ behavior: "smooth" });
                      }}
                      className="mt-4 flex items-center gap-2 bg-primary text-white text-sm font-semibold px-5 py-2.5 rounded-xl hover:bg-primary/90 transition-colors"
                      data-testid={`button-visa-apply-${visa.id}`}
                    >
                      Apply for {visa.country} <FileText className="h-4 w-4" />
                    </button>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Enquiry Section */}
      <section className="py-20 bg-gradient-to-br from-primary/5 to-accent/5" id="visa-enquiry">
        <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-10">
            <h2
              className="text-3xl sm:text-4xl font-bold text-foreground mb-3"
              style={{ fontFamily: "'Playfair Display', serif" }}
            >
              Start Your Visa Application
            </h2>
            <p className="text-muted-foreground text-lg">
              Fill the form below and our visa expert will guide you through the entire process.
            </p>
          </div>
          <div className="bg-white rounded-3xl shadow-xl border border-border p-8 sm:p-10">
            <EnquiryForm defaultDestination="Schengen Visa" />
          </div>
          <div className="mt-8 flex flex-col sm:flex-row items-center justify-center gap-6 text-sm text-muted-foreground">
            <a href="tel:6297076072" className="flex items-center gap-2 hover:text-primary transition-colors" data-testid="visa-phone">
              <Phone className="h-4 w-4 text-accent" />
              6297076072
            </a>
            <a href="mailto:info@globaltrottertraveller.com" className="flex items-center gap-2 hover:text-primary transition-colors" data-testid="visa-email">
              <Mail className="h-4 w-4 text-accent" />
              info@globaltrottertraveller.com
            </a>
          </div>
        </div>
      </section>
    </div>
  );
}
