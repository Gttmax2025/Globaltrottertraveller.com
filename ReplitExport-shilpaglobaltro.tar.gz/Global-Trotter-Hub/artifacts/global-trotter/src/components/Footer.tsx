import { Link } from "wouter";
import { Phone, Mail, MapPin, Globe } from "lucide-react";

export default function Footer() {
  return (
    <footer className="bg-[hsl(220,40%,12%)] text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10">
          <div className="lg:col-span-1">
            <img
              src="/logo.png"
              alt="Global Trotter Traveller"
              className="h-20 w-auto object-contain mb-4"
            />
            <p className="text-white/70 text-sm leading-relaxed">
              From Here to Everywhere. Your trusted travel partner for unforgettable journeys across India and beyond.
            </p>
          </div>

          <div>
            <h3 className="text-accent font-semibold text-lg mb-4" style={{ fontFamily: "'Playfair Display', serif" }}>Our Services</h3>
            <ul className="space-y-2 text-white/70 text-sm">
              <li><Link href="/domestic" className="hover:text-accent transition-colors">Domestic Packages</Link></li>
              <li><Link href="/international" className="hover:text-accent transition-colors">International Packages</Link></li>
              <li className="hover:text-accent transition-colors cursor-default">Hotel Booking</li>
              <li className="hover:text-accent transition-colors cursor-default">Flight Booking</li>
              <li><Link href="/visa" className="hover:text-accent transition-colors">Visa Services</Link></li>
            </ul>
          </div>

          <div>
            <h3 className="text-accent font-semibold text-lg mb-4" style={{ fontFamily: "'Playfair Display', serif" }}>Quick Links</h3>
            <ul className="space-y-2 text-white/70 text-sm">
              <li><Link href="/" className="hover:text-accent transition-colors">Home</Link></li>
              <li><Link href="/domestic" className="hover:text-accent transition-colors">Domestic Packages</Link></li>
              <li><Link href="/international" className="hover:text-accent transition-colors">International Packages</Link></li>
              <li><Link href="/visa" className="hover:text-accent transition-colors">Visa Services</Link></li>
              <li><Link href="/contact" className="hover:text-accent transition-colors">Contact Us</Link></li>
            </ul>
          </div>

          <div>
            <h3 className="text-accent font-semibold text-lg mb-4" style={{ fontFamily: "'Playfair Display', serif" }}>Contact Us</h3>
            <ul className="space-y-3 text-white/70 text-sm">
              <li className="flex items-center gap-3">
                <Phone className="h-4 w-4 text-accent flex-shrink-0" />
                <a href="tel:6297076072" className="hover:text-accent transition-colors" data-testid="footer-phone">6297076072</a>
              </li>
              <li className="flex items-center gap-3">
                <Mail className="h-4 w-4 text-accent flex-shrink-0" />
                <a href="mailto:info@globaltrottertraveller.com" className="hover:text-accent transition-colors break-all" data-testid="footer-email">
                  info@globaltrottertraveller.com
                </a>
              </li>
              <li className="flex items-start gap-3">
                <Globe className="h-4 w-4 text-accent flex-shrink-0 mt-0.5" />
                <span>Global Trotter Traveller<br />From Here to Everywhere</span>
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t border-white/10 mt-12 pt-8 text-center text-white/50 text-sm">
          <p>&copy; {new Date().getFullYear()} Global Trotter Traveller. All rights reserved.</p>
          <p className="mt-1 text-white/30">From Here to Everywhere</p>
        </div>
      </div>
    </footer>
  );
}
