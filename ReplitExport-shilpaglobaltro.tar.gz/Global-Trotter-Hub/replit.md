# Workspace

## Overview

pnpm workspace monorepo using TypeScript. Each package manages its own dependencies.

## Stack

- **Monorepo tool**: pnpm workspaces
- **Node.js version**: 24
- **Package manager**: pnpm
- **TypeScript version**: 5.9
- **API framework**: Express 5
- **Database**: PostgreSQL + Drizzle ORM
- **Validation**: Zod (`zod/v4`), `drizzle-zod`
- **API codegen**: Orval (from OpenAPI spec)
- **Build**: esbuild (CJS bundle)

## Key Commands

- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- `pnpm --filter @workspace/api-server run dev` — run API server locally

See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details.

## Artifacts

### Global Trotter Traveller (`artifacts/global-trotter`)
- **Type**: React + Vite (frontend-only, no backend needed)
- **Preview path**: `/`
- **Purpose**: Travel agency website for Global Trotter Traveller

#### Pages
- `/` — Home page: hero, services overview, popular destinations, enquiry form
- `/domestic` — Domestic Packages: Goa, Kerala, Rajasthan, Himachal Pradesh, Leh Ladakh, Andaman
- `/international` — International Packages: Dubai, Paris, Singapore, Maldives, Thailand, Switzerland
- `/visa` — Visa Services: expandable checklists for Schengen, USA, UK, Dubai, Singapore, Thailand
- `/contact` — Contact Us: contact info and enquiry form

#### Key Features
- Logo at `public/logo.png` (referenced as `/logo.png`)
- Enquiry form with mailto: to info@globaltrottertraveller.com
- Phone number: 6297076072
- Destination dropdown with Domestic, International, and Visa categories
- Visa document checklists (accordion-style)
- Enquiry modal on package cards

#### Components
- `src/components/Navbar.tsx` — Fixed nav with logo, links, phone number, mobile menu
- `src/components/Footer.tsx` — Footer with services, quick links, contact info
- `src/components/EnquiryForm.tsx` — Reusable enquiry form (mailto integration)
