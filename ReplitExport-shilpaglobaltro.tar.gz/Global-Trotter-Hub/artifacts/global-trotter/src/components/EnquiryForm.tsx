import { useState } from "react";
import { Send } from "lucide-react";

const domesticDestinations = [
  "Goa",
  "Kerala Backwaters",
  "Rajasthan",
  "Himachal Pradesh",
  "Leh Ladakh",
  "Andaman & Nicobar",
  "Ooty & Coorg",
  "Varanasi",
  "Arunachal with Tawang",
  "Anini Mechuka Route",
  "Kashmir",
  "Assam & Meghalaya",
  "Dalhousie & Dharamshala",
  "Spiti Valley",
];

const internationalDestinations = [
  "Dubai",
  "Paris",
  "Singapore",
  "Maldives",
  "Phuket & Krabi",
  "Bangkok & Pattaya",
  "Bali",
  "Malaysia",
  "Switzerland",
  "Vietnam",
  "UK & Scotland",
  "Eastern Europe",
  "New York",
  "Australia",
];

const visaDestinations = [
  "Schengen Visa",
  "USA Visa",
  "UK Visa",
  "Dubai Visa",
  "Singapore Visa",
  "Thailand Visa",
  "Australia Visa",
  "Canada Visa",
];

interface EnquiryFormProps {
  defaultDestination?: string;
  compact?: boolean;
}

export default function EnquiryForm({ defaultDestination = "", compact = false }: EnquiryFormProps) {
  const [name, setName] = useState("");
  const [mobile, setMobile] = useState("");
  const [destination, setDestination] = useState(defaultDestination);
  const [adults, setAdults] = useState("2");
  const [children, setChildren] = useState("0");
  const [travelDate, setTravelDate] = useState("");
  const [packageType, setPackageType] = useState("");
  const [message, setMessage] = useState("");
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const subject = encodeURIComponent(`Travel Enquiry - ${destination || "General"}`);
    const body = encodeURIComponent(
      `Name: ${name}\nMobile: ${mobile}\nDestination: ${destination}\nAdults: ${adults}\nChildren: ${children}\nTravel Date: ${travelDate || "Not specified"}\nPackage Type: ${packageType || "Not specified"}\nMessage: ${message}`
    );
    window.location.href = `mailto:info@globaltrottertraveller.com?subject=${subject}&body=${body}`;
    setSubmitted(true);
  };

  if (submitted) {
    return (
      <div className="bg-green-50 border border-green-200 rounded-2xl p-8 text-center">
        <div className="text-5xl mb-4 text-green-500">&#10003;</div>
        <h3 className="text-xl font-bold text-green-800 mb-2">Enquiry Sent!</h3>
        <p className="text-green-700">Your enquiry has been submitted. We will contact you at {mobile} shortly.</p>
        <button
          onClick={() => setSubmitted(false)}
          className="mt-4 text-primary underline text-sm"
        >
          Submit another enquiry
        </button>
      </div>
    );
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-4" data-testid="form-enquiry">
      {/* Row 1: Name + Mobile */}
      <div className={compact ? "grid grid-cols-1 gap-4" : "grid grid-cols-1 md:grid-cols-2 gap-4"}>
        <div>
          <label className="block text-sm font-medium text-foreground mb-1.5">
            Your Name <span className="text-red-500">*</span>
          </label>
          <input
            type="text"
            required
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="Enter your full name"
            className="w-full px-4 py-3 rounded-xl border border-border bg-white text-foreground placeholder-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/40 focus:border-primary transition-all"
            data-testid="input-name"
          />
        </div>
        <div>
          <label className="block text-sm font-medium text-foreground mb-1.5">
            Mobile Number <span className="text-red-500">*</span>
          </label>
          <input
            type="tel"
            required
            value={mobile}
            onChange={(e) => setMobile(e.target.value)}
            placeholder="+91 XXXXX XXXXX"
            className="w-full px-4 py-3 rounded-xl border border-border bg-white text-foreground placeholder-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/40 focus:border-primary transition-all"
            data-testid="input-mobile"
          />
        </div>
      </div>

      {/* Row 2: Destination */}
      <div>
        <label className="block text-sm font-medium text-foreground mb-1.5">
          Select Destination / Service <span className="text-red-500">*</span>
        </label>
        <select
          required
          value={destination}
          onChange={(e) => setDestination(e.target.value)}
          className="w-full px-4 py-3 rounded-xl border border-border bg-white text-foreground focus:outline-none focus:ring-2 focus:ring-primary/40 focus:border-primary transition-all appearance-none cursor-pointer"
          data-testid="select-destination"
        >
          <option value="">-- Choose a Destination or Service --</option>
          <optgroup label="Domestic Destinations">
            {domesticDestinations.map((d) => (
              <option key={d} value={d}>{d}</option>
            ))}
          </optgroup>
          <optgroup label="International Destinations">
            {internationalDestinations.map((d) => (
              <option key={d} value={d}>{d}</option>
            ))}
          </optgroup>
          <optgroup label="Visa Services">
            {visaDestinations.map((d) => (
              <option key={d} value={d}>{d}</option>
            ))}
          </optgroup>
        </select>
      </div>

      {/* Row 3: Adults + Children */}
      <div className="grid grid-cols-2 gap-4">
        <div>
          <label className="block text-sm font-medium text-foreground mb-1.5">
            Number of Adults <span className="text-red-500">*</span>
          </label>
          <select
            required
            value={adults}
            onChange={(e) => setAdults(e.target.value)}
            className="w-full px-4 py-3 rounded-xl border border-border bg-white text-foreground focus:outline-none focus:ring-2 focus:ring-primary/40 focus:border-primary transition-all appearance-none cursor-pointer"
            data-testid="select-adults"
          >
            {[1,2,3,4,5,6,7,8,9,10].map((n) => (
              <option key={n} value={n}>{n} Adult{n > 1 ? "s" : ""}</option>
            ))}
            <option value="10+">10+ Adults</option>
          </select>
        </div>
        <div>
          <label className="block text-sm font-medium text-foreground mb-1.5">
            Number of Children
          </label>
          <select
            value={children}
            onChange={(e) => setChildren(e.target.value)}
            className="w-full px-4 py-3 rounded-xl border border-border bg-white text-foreground focus:outline-none focus:ring-2 focus:ring-primary/40 focus:border-primary transition-all appearance-none cursor-pointer"
            data-testid="select-children"
          >
            {[0,1,2,3,4,5,6].map((n) => (
              <option key={n} value={n}>{n} {n === 1 ? "Child" : "Children"}</option>
            ))}
            <option value="6+">6+ Children</option>
          </select>
        </div>
      </div>

      {/* Row 4: Travel Date + Package Type */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <label className="block text-sm font-medium text-foreground mb-1.5">
            Travel Date
          </label>
          <input
            type="date"
            value={travelDate}
            onChange={(e) => setTravelDate(e.target.value)}
            min={new Date().toISOString().split("T")[0]}
            className="w-full px-4 py-3 rounded-xl border border-border bg-white text-foreground focus:outline-none focus:ring-2 focus:ring-primary/40 focus:border-primary transition-all cursor-pointer"
            data-testid="input-travel-date"
          />
        </div>
        <div>
          <label className="block text-sm font-medium text-foreground mb-1.5">
            Package Type
          </label>
          <select
            value={packageType}
            onChange={(e) => setPackageType(e.target.value)}
            className="w-full px-4 py-3 rounded-xl border border-border bg-white text-foreground focus:outline-none focus:ring-2 focus:ring-primary/40 focus:border-primary transition-all appearance-none cursor-pointer"
            data-testid="select-package-type"
          >
            <option value="">-- Select Package Type --</option>
            <option value="Fixed Departure">Fixed Departure</option>
            <option value="Low Budget">Low Budget</option>
            <option value="High Budget">High Budget</option>
          </select>
        </div>
      </div>

      {/* Row 5: Message */}
      <div>
        <label className="block text-sm font-medium text-foreground mb-1.5">
          Additional Requirements
        </label>
        <textarea
          value={message}
          onChange={(e) => setMessage(e.target.value)}
          placeholder="Tell us about any special requirements, preferred hotels, dietary needs, etc..."
          rows={compact ? 2 : 3}
          className="w-full px-4 py-3 rounded-xl border border-border bg-white text-foreground placeholder-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/40 focus:border-primary transition-all resize-none"
          data-testid="textarea-message"
        />
      </div>

      <button
        type="submit"
        className="w-full flex items-center justify-center gap-2 bg-accent hover:bg-accent/90 text-white font-semibold py-3.5 px-6 rounded-xl transition-all duration-200 shadow-lg hover:shadow-xl hover:scale-[1.01] active:scale-[0.99]"
        data-testid="button-submit-enquiry"
      >
        <Send className="h-4 w-4" />
        Send Enquiry
      </button>

      <p className="text-xs text-muted-foreground text-center">
        By submitting, you agree to be contacted at the provided mobile number. Your enquiry will be sent to info@globaltrottertraveller.com
      </p>
    </form>
  );
}
