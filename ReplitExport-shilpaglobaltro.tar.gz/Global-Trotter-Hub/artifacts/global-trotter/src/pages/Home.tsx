import { Link } from "wouter";
import { Plane, Hotel, Globe, FileText, MapPin, Phone, Mail, ArrowRight, Star, Shield, Users } from "lucide-react";
import EnquiryForm from "@/components/EnquiryForm";

const services = [
  {
    icon: MapPin,
    title: "Domestic Packages",
    description: "Explore the breathtaking diversity of India — from tropical beaches to snow-capped Himalayas, ancient heritage to vibrant cities.",
    href: "/domestic",
    color: "text-blue-600",
    bg: "bg-blue-50",
  },
  {
    icon: Globe,
    title: "International Packages",
    description: "Discover the world with our expertly curated international tour packages to Europe, Asia, Middle East, and beyond.",
    href: "/international",
    color: "text-emerald-600",
    bg: "bg-emerald-50",
  },
  {
    icon: Hotel,
    title: "Hotel Booking",
    description: "Best-rate hotel reservations across all categories — from luxury 5-star resorts to comfortable budget accommodations.",
    href: "/contact",
    color: "text-purple-600",
    bg: "bg-purple-50",
  },
  {
    icon: Plane,
    title: "Flight Booking",
    description: "Hassle-free domestic and international flight bookings with the best fares and convenient schedules.",
    href: "/contact",
    color: "text-sky-600",
    bg: "bg-sky-50",
  },
  {
    icon: FileText,
    title: "Visa Services",
    description: "Expert visa assistance for all major destinations — Schengen, USA, UK, Dubai, Singapore, and more with complete documentation guidance.",
    href: "/visa",
    color: "text-amber-600",
    bg: "bg-amber-50",
  },
];

const destinations = [
  { name: "Dubai", img: "https://images.unsplash.com/photo-1512453979798-5ea266f8880c?w=400&h=300&fit=crop", type: "International" },
  { name: "Kerala", img: "https://images.unsplash.com/photo-1593693397690-362cb9666fc2?w=400&h=300&fit=crop", type: "Domestic" },
  { name: "Paris", img: "https://images.unsplash.com/photo-1502602898657-3e91760cbb34?w=400&h=300&fit=crop", type: "International" },
  { name: "Rajasthan", img: "https://images.unsplash.com/photo-1599661046827-dacff0c0f09a?w=400&h=300&fit=crop", type: "Domestic" },
  { name: "Maldives", img: "https://images.unsplash.com/photo-1573843981267-be1999ff37cd?w=400&h=300&fit=crop", type: "International" },
  { name: "Leh Ladakh", img: "https://images.unsplash.com/photo-1626621341517-bbf3d9990a23?w=400&h=300&fit=crop", type: "Domestic" },
];

const stats = [
  { value: "5000+", label: "Happy Travelers" },
  { value: "100+", label: "Destinations" },
  { value: "10+", label: "Years Experience" },
  { value: "24/7", label: "Customer Support" },
];

const features = [
  { icon: Shield, title: "Trusted & Reliable", desc: "Licensed travel agency with years of proven expertise" },
  { icon: Star, title: "Best Prices", desc: "Competitive rates with no hidden charges" },
  { icon: Users, title: "Dedicated Support", desc: "Personal travel consultant for every booking" },
];

export default function Home() {
  return (
    <div className="pt-20">
      {/* Hero Section */}
      <section className="relative min-h-[90vh] flex items-center overflow-hidden bg-[hsl(220,40%,12%)]">
        <div
          className="absolute inset-0 bg-cover bg-center opacity-30"
          style={{
            backgroundImage:
              "url('https://images.unsplash.com/photo-1476514525535-07fb3b4ae5f1?w=1600&h=900&fit=crop')",
          }}
        />
        <div className="absolute inset-0 bg-gradient-to-r from-[hsl(220,40%,8%)] via-[hsl(220,40%,10%)]/80 to-transparent" />

        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20 w-full">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            {/* Left: Headline */}
            <div>
              <div className="inline-flex items-center gap-2 bg-accent/20 text-accent border border-accent/30 rounded-full px-4 py-1.5 text-sm font-medium mb-6">
                <Globe className="h-4 w-4" />
                Your Premier Travel Partner
              </div>
              <h1
                className="text-5xl sm:text-6xl lg:text-7xl font-bold text-white leading-tight mb-6"
                style={{ fontFamily: "'Playfair Display', serif" }}
              >
                From Here to
                <span className="block text-accent">Everywhere</span>
              </h1>
              <p className="text-white/80 text-lg leading-relaxed mb-8">
                Discover extraordinary destinations with Global Trotter Traveller. We craft personalized journeys that turn your travel dreams into unforgettable memories.
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <Link
                  href="/domestic"
                  className="inline-flex items-center justify-center gap-2 bg-accent hover:bg-accent/90 text-white font-semibold px-8 py-4 rounded-xl transition-all duration-200 shadow-lg hover:shadow-xl hover:scale-[1.02] active:scale-[0.99]"
                  data-testid="link-explore-packages"
                >
                  Explore Packages
                  <ArrowRight className="h-5 w-5" />
                </Link>
                <a
                  href="tel:6297076072"
                  className="inline-flex items-center justify-center gap-2 bg-white/10 hover:bg-white/20 text-white border border-white/30 font-semibold px-8 py-4 rounded-xl transition-all duration-200 backdrop-blur-sm"
                  data-testid="link-call-now"
                >
                  <Phone className="h-5 w-5" />
                  Call Now: 6297076072
                </a>
              </div>
            </div>

            {/* Right: Enquiry Form */}
            <div className="bg-white/95 backdrop-blur-md rounded-3xl shadow-2xl p-6 sm:p-8 border border-white/20">
              <div className="mb-5">
                <h2
                  className="text-2xl font-bold text-foreground mb-1"
                  style={{ fontFamily: "'Playfair Display', serif" }}
                >
                  Plan Your Trip
                </h2>
                <p className="text-muted-foreground text-sm">
                  Send us an enquiry — we'll get back within 24 hours.
                </p>
              </div>
              <EnquiryForm compact />
            </div>
          </div>
        </div>

        <div className="absolute bottom-0 left-0 right-0">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-6">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {stats.map((stat) => (
                <div key={stat.label} className="bg-white/10 backdrop-blur-sm border border-white/20 rounded-2xl p-4 text-center">
                  <div className="text-3xl font-bold text-accent" style={{ fontFamily: "'Playfair Display', serif" }}>{stat.value}</div>
                  <div className="text-white/70 text-sm mt-1">{stat.label}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section className="py-24 bg-background">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <div className="inline-flex items-center gap-2 text-accent text-sm font-semibold tracking-widest uppercase mb-3">
              What We Offer
            </div>
            <h2
              className="text-4xl sm:text-5xl font-bold text-foreground mb-4"
              style={{ fontFamily: "'Playfair Display', serif" }}
            >
              Our Travel Services
            </h2>
            <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
              Everything you need for the perfect trip — expertly handled from start to finish.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {services.map((service) => (
              <Link
                key={service.title}
                href={service.href}
                className="group bg-white border border-border rounded-2xl p-8 hover:shadow-xl transition-all duration-300 hover:-translate-y-1"
                data-testid={`card-service-${service.title.toLowerCase().replace(/\s+/g, "-")}`}
              >
                <div className={`inline-flex items-center justify-center w-14 h-14 rounded-2xl ${service.bg} mb-6`}>
                  <service.icon className={`h-7 w-7 ${service.color}`} />
                </div>
                <h3 className="text-xl font-bold text-foreground mb-3 group-hover:text-primary transition-colors" style={{ fontFamily: "'Playfair Display', serif" }}>
                  {service.title}
                </h3>
                <p className="text-muted-foreground leading-relaxed text-sm">{service.description}</p>
                <div className="mt-4 flex items-center gap-1 text-primary font-medium text-sm">
                  Learn More <ArrowRight className="h-4 w-4 group-hover:translate-x-1 transition-transform" />
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* Popular Destinations */}
      <section className="py-24 bg-muted/40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <div className="inline-flex items-center gap-2 text-accent text-sm font-semibold tracking-widest uppercase mb-3">
              Popular Destinations
            </div>
            <h2
              className="text-4xl sm:text-5xl font-bold text-foreground mb-4"
              style={{ fontFamily: "'Playfair Display', serif" }}
            >
              Explore the World
            </h2>
            <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
              Handpicked destinations that promise extraordinary experiences.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {destinations.map((dest) => (
              <Link
                key={dest.name}
                href={dest.type === "Domestic" ? "/domestic" : "/international"}
                className="group relative overflow-hidden rounded-2xl aspect-[4/3] block"
                data-testid={`card-destination-${dest.name.toLowerCase()}`}
              >
                <img
                  src={dest.img}
                  alt={dest.name}
                  className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent" />
                <div className="absolute bottom-0 left-0 right-0 p-6">
                  <span className="inline-block bg-accent text-white text-xs font-semibold px-3 py-1 rounded-full mb-2">
                    {dest.type}
                  </span>
                  <h3 className="text-white text-2xl font-bold" style={{ fontFamily: "'Playfair Display', serif" }}>
                    {dest.name}
                  </h3>
                </div>
              </Link>
            ))}
          </div>

          <div className="text-center mt-10 flex flex-col sm:flex-row gap-4 justify-center">
            <Link
              href="/domestic"
              className="inline-flex items-center gap-2 bg-primary text-white font-semibold px-8 py-3.5 rounded-xl hover:bg-primary/90 transition-all hover:shadow-lg"
              data-testid="link-domestic-packages"
            >
              Domestic Packages <ArrowRight className="h-4 w-4" />
            </Link>
            <Link
              href="/international"
              className="inline-flex items-center gap-2 bg-accent text-white font-semibold px-8 py-3.5 rounded-xl hover:bg-accent/90 transition-all hover:shadow-lg"
              data-testid="link-international-packages"
            >
              International Packages <ArrowRight className="h-4 w-4" />
            </Link>
          </div>
        </div>
      </section>

      {/* Why Choose Us */}
      <section className="py-24 bg-background">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2
              className="text-4xl sm:text-5xl font-bold text-foreground mb-4"
              style={{ fontFamily: "'Playfair Display', serif" }}
            >
              Why Choose Global Trotter Traveller?
            </h2>
            <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
              We go beyond booking to create experiences that stay with you forever.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {features.map((f) => (
              <div key={f.title} className="text-center p-8 bg-white rounded-2xl border border-border shadow-sm hover:shadow-md transition-all">
                <div className="inline-flex items-center justify-center w-16 h-16 bg-primary/10 rounded-2xl mb-6 mx-auto">
                  <f.icon className="h-8 w-8 text-primary" />
                </div>
                <h3 className="text-xl font-bold text-foreground mb-3" style={{ fontFamily: "'Playfair Display', serif" }}>{f.title}</h3>
                <p className="text-muted-foreground">{f.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Enquiry Section */}
      <section className="py-24 bg-gradient-to-br from-primary/5 to-accent/5" id="enquiry">
        <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <div className="inline-flex items-center gap-2 text-accent text-sm font-semibold tracking-widest uppercase mb-3">
              Get In Touch
            </div>
            <h2
              className="text-4xl sm:text-5xl font-bold text-foreground mb-4"
              style={{ fontFamily: "'Playfair Display', serif" }}
            >
              Plan Your Dream Trip
            </h2>
            <p className="text-muted-foreground text-lg">
              Fill in your details and our travel expert will reach out to you within 24 hours.
            </p>
          </div>
          <div className="bg-white rounded-3xl shadow-xl border border-border p-8 sm:p-12">
            <EnquiryForm />
          </div>
          <div className="mt-8 flex flex-col sm:flex-row items-center justify-center gap-6 text-sm text-muted-foreground">
            <a href="tel:6297076072" className="flex items-center gap-2 hover:text-primary transition-colors" data-testid="home-phone">
              <Phone className="h-4 w-4 text-accent" />
              6297076072
            </a>
            <a href="mailto:info@globaltrottertraveller.com" className="flex items-center gap-2 hover:text-primary transition-colors" data-testid="home-email">
              <Mail className="h-4 w-4 text-accent" />
              info@globaltrottertraveller.com
            </a>
          </div>
        </div>
      </section>
    </div>
  );
}
